const pool = require("../../config/database");
var nodemailer = require("nodemailer");
const transporter = nodemailer.createTransport({
    host: 'smtp.ethereal.email',
    port: 587,
    auth: {
        user: 'doyle.koepp38@ethereal.email',
        pass: 'X9tt2f6Bapw4sTDGeB'
    }
});
module.exports = {
  addUser: (data, callBack) => {
    pool.query(
      `insert into maz_ecommerce.user set  email=?, password=? , type='user' , created_at = now()`,
        [
        data.email,
        data.password
      ],
      (error, results, fields) => {
        if (error) {
          return callBack(error,null);
        }
        delete data.email;
        delete data.password;
        delete data.type;
        console.log("results  are ",results)
        pool.query(
          `insert into maz_ecommerce.profile set user_id=${results.insertId}, `+Object.keys(data).map(key => `${key} = ?`).join(", ") +"",
            [
              ...Object.values(data)
          ],
          (error, result, fields) => {
            if (error) {
              return callBack(error,null);
            }
            result['user_id']=results.insertId
            return callBack(null,  result);
          }
        );
      }
    );
  },
  addAdminByAdmin: (data, callBack) => {
    let type='user'
    if(data.type!='admin')
    type='admin'
    pool.query(
      `insert into maz_ecommerce.user set  email=?, password=? , type='${type}' , created_at = now()`,
        [
        data.email,
        data.password
      ],
      (error, results, fields) => {
        if (error) {
          return callBack(error,null);
        }
        delete data.email;
        delete data.password;
        delete data.type;
        console.log("results  are ",results)
        pool.query(
          `insert into maz_ecommerce.profile set user_id=${results.insertId}, `+Object.keys(data).map(key => `${key} = ?`).join(", ") +"",
            [
              ...Object.values(data)
          ],
          (error, result, fields) => {
            if (error) {
              return callBack(error,null);
            }
            result['user_id']=results.insertId
            return callBack(null,  result);
          }
        );
      }
    );
  },
  getUserByUserEmail: (email, callBack) => {
    pool.query(
      `select * from maz_ecommerce.user as u inner join profile as p on u.id=p.user_id where email = ?`,
      [email],
      (error, results, fields) => {
        if (error) {
          return callBack(error,null);
        }
        return callBack(null, results[0]);
      }
    );
  },
  getUserByUserName: (username, callBack) => {
    pool.query(
      `select * from maz_ecommerce.user where user_name = ?`,
      [username],
      (error, results, fields) => {
        if (error) {
          return callBack(error,null);
        }
        return callBack(null, results[0]);
      }
    );
  },
  getUserByUserId: (id, callBack) => {
    pool.query(
      `select * from maz_ecommerce.user inner join maz_ecommerce.profile on maz_ecommerce.user.id=maz_ecommerce.profile.user_id where maz_ecommerce.user.id = ? `,
      [id],
      (error, results, fields) => {
        if (error) {
          return callBack(error);
        }
        return callBack(null, results[0]);
      }
    );
  },
  getAllUsers: (callBack) => {
       pool.query(
      `select * from maz_ecommerce.user inner join maz_ecommerce.profile on maz_ecommerce.user.id=maz_ecommerce.profile.user_id`,
        [],
      (error, results, fields) => {
        if (error) {
          return callBack(error,null);
        }
        return callBack(null, results);
      }
    );
  },
  getAllUserProfiles: (callBack) => {
    pool.query(
   `select * from maz_ecommerce.profile`,
     [],
   (error, results, fields) => {
     if (error) {
       return callBack(error,null);
     }
     return callBack(null, results);
   }
 );
},
  updateUserNameByUserId: (id,username, callBack) => {
    pool.query(
      `update maz_ecommerce.user set user_name=? where id =?`,
        [
          username,
          id
      ],
      (error, result, fields) => {
        if (error) {
          return callBack(error,null);
        }
        return callBack(null, result);
      }
    );
    
  },
  updatePasswordByUserId: (data, callBack) => {
    pool.query(
      `update maz_ecommerce.user set password=? where id = ?`,
      [
        data.password,
        data.id
      ],
      (error, results, fields) => {
        if (error) {
          return callBack(error);
        }
        return callBack(null, results[0]);
      }
    );
  },
  deleteUserByUserId: (id, callBack) => {
    pool.query(
      `delete from maz_ecommerce.user where id = ?`,
      [id],
      (error, results, fields) => {
        if (error) {
          console.log("error occured "+err)
          return callBack(error,null);
        }
        console.log("results are "+results[0])
        return callBack(null,results[0]);
      }
    );
  },
  updateLoginStatus: (login,status,rememberToken, callBack) => {
    if(login)
    {
    pool.query(
      `update maz_ecommerce.user set last_login=now(),isActive=?,remember_token=? where id = ?`,
      [
        status,
        rememberToken,
        id

      ],
      (error, results, fields) => {
        if (error) {
          console.log("error occured "+err)
          return callBack(error);
        }
        console.log("results are "+results[0])
        return callBack(null);
      }
    );
    }
    else{
      pool.query(
        `insert into maz_ecommerce.user set isActive=?,remember_token=? where id = ?`,
        [
          status,
          rememberToken,
          id
  
        ],
        (error, results, fields) => {
          if (error) {
            console.log("error occured "+err)
            return callBack(error);
          }
          console.log("results are "+results[0])
          return callBack(null);
        }
      );
    }
  },
  sendMail:(msg,token,callBack)=>
  {
      
   // const maillist=emails
    var mailOptions = {
      from: 'areebraja000@gmail.com',
      to: 'areebraja000@gmail.com',
      subject: 'Activation Link',
      text: 'Your Activation Link is'+ token  
    };
    
    transporter.sendMail(mailOptions, function(error, info){
      if (error) {
        console.log(error);
        return res.status(500).json({
          success: 0,
          message: "Null Data",
          error: 'null data',
        });
      } else {
        console.log('Email sent: ' + info.response);
        return res.status(200).json({
          success: 1,
          message: "Mail Sent",
          
        });
      }
    });
      
      
    // const mailgun = require("mailgun-js");
    // const DOMAIN = "sandbox4c656a09d3e34e0db52944f28a922d5f.mailgun.org";
    // const mg = mailgun({
    //   apiKey: "cb29bdfc53d33a8895033abb2c1ea31b-45f7aa85-25443ef7",
    //   domain: DOMAIN,
    // });
    // const data = {
    //   from: "areebraja000@gmail.com",
    //   to: 'areebraja000@gmail.com',
    //   subject: "Email Verification",
    //   html: `<h2>${msg.message}</h2>
    //   <a>${token}</a>`,
    // };
    // mg.messages().send(data, (err,result)=> {
    //   if (err) {
    //     return callBack(err,null)
    //   }
    //   return callBack(null,result)
      
    // });
  },
  activateUserAccount: (id, callBack) => {
    console.log("in activate account")
    pool.query(
      `update maz_ecommerce.user set isVerified=1 where id = ?`,
      [id],
      (error, results, fields) => {
        if (error) {
          return callBack(error,null);
        }
        return callBack(null,results);
      }
    );
  },

updateUserProfileByUserId: (id,data, callBack) => {
  pool.query(
    `update maz_ecommerce.profile set `+Object.keys(data).map(key => `${key} = ?`).join(", ") +" where id =?",
      [
        ...Object.values(data),
        id
    ],
    (error, result, fields) => {
      if (error) {
        return callBack(error,null);
      }
      return callBack(null, result);
    }
  );
},
deleteAllUsers: (callBack) => {
  pool.query(
    `delete from maz_ecommerce.user`,
    [],
    (error, results, fields) => {
      if (error) {
        console.log("error occured "+err)
        return callBack(error,null);
      }
      console.log("results are "+results)
      return callBack(null,results);
    }
  );
},
updatelastlogin: (date,id,callBack) => {
  pool.query(
    `update maz_ecommerce.user set last_login=? where id=?` ,
    [date,id],
    (error, results, fields) => {
      if (error) {
        console.log("error occured "+error)
        return callBack(error,null);
      }
      console.log("results are "+results)
      return callBack(null,results);
    }
  );
}
};