const router = require("express").Router();
const { checkToken, isAdmin } = require("../../auth/token_validation");
const {
getAllSuppliers,
addSupplier,
deleteAllSuppliers,
getSupplierById,
updateSupplierById,
deleteSupplierById,
getSuppliersByProductId,
getProductsProvidedBySupplierUsingSupplierId

} = require("./supplier.controller");
const use = fn => (req,res,next)=>
{
    Promise.resolve(fn(req,res,next)).catch(next)
}
router.get("/", use(getAllSuppliers));
router.get("/getProductProvidedBySupplier/:id",use(getProductsProvidedBySupplierUsingSupplierId));

router.get("/getSuppliersOfProduct/:id",use(getSuppliersByProductId));
router.get("/:id",use(getSupplierById));
//By giving product id will give you the Supplier assign to that product 

router.post("/", use(addSupplier));
router.delete("/", use(deleteAllSuppliers));
router.put("/:id",use(updateSupplierById));
router.delete("/:id",use(deleteSupplierById));
module.exports = router;