const { getConnection } = require("../../config/database");
const pool = require("../../config/database");
// const path =require('path')
addProductVariantDetails = (id, valueId) => {
  console.log("in add product cariants");
  return new Promise((resolve, reject) => {
    let sql =
      "INSERT INTO maz_maz_ecommerce.product_variant_details set product_variant_id= ?,variant_value_id=? ";
    pool.query(sql, [id, valueId], (error, results, fields) => {
      if (error) {
        console.log("adding details error",error);
        return reject(error);
      }
      console.log("adding details result", results);
      return resolve(results);
    });
  });
};
addVariantValue= (variant_id, variant_value) => {
  return new Promise((resolve, reject) => {
    let sql = "INSERT INTO maz_ecommerce.variant_values set variant_id=?,value=? ";
    pool.query(sql, [variant_id,variant_value], (error, results, fields) => {
      if (error) {
        console.log("error adding variant value added",error)
        return reject(error);
      }
      console.log("variant value added",results)
      return resolve(results);
    });
  });
};
searchProductVariantValue = (variant_value) => {
  console.log("in add product cariants");
  return new Promise((resolve, reject) => {
    sql = `SELECT id FROM maz_ecommerce.variant_values as varval where varval.value like '${variant_value}'`;
    pool.query(sql, [], (error, results, fields) => {
      if (error) {
        console.log("the errrror is", error);
        return reject(error);
      }
      console.log("result in searching variant value is", results);
      resolve(results);
    });
  });
};
module.exports = {
  addProduct: (data) => {
    return new Promise((resolve, reject) => {
      if (data.variants) {
        console.log('areeb datta',data)
        pool.query(
          `insert into maz_ecommerce.product set name=?, category_id=?, product_description=?,supplier_id=?,price=?, has_variant=1`,
          [
            data.name,
            data.category_id,
            data.product_description,
            data.supplier_id,
            data.price,
          ],
          (error, results, fields) => {
            console.log('my reslt',results)
            if (error) {
              console.log('heloo',error)
              return reject(error);
            }
            resolve(results);
          }
        );
      } else {
        console.log("in addd",data);
        pool.query(
          `insert into maz_ecommerce.product set name=?, category_id=?, product_description=?,supplier_id=?,part_no=?,regular_price=?,stock_status=?,stock_quantity=?,low_stock_threshold=?,discounted_price=?,oem_no=?,application=?,package=?,vehicle_id=?`,
          [
            data.name,
            data.category_id,
            data.product_description,
            data.supplier_id,
            data.part_no,
            data.regular_price,
            '10',
            data.stock_quantity,
            '5',
            200,
            data.oem_no,
            data.application,
            data.package,
            data.vehicle_id,
            data.cross_ref
          ],
          (error, results, fields) => {
            if (error) {
              console.log('error',error)
              return reject(error);
            }
            console.log('ressss',results)
            resolve(results);
          }
        );
      }
    });
  },
  getProductBySKU: (part_no, variant) => {
    return new Promise((resolve, reject) => {
      var table = "";
      if (variant) table = "product_variants";
      else table = "product";
      console.log("var", variant, table);

      pool.query(
        `select id from maz_ecommerce.${table} where part_no=?`,
        [part_no],
        (error, result, fields) => {
          console.log("sku", result, error);
          if (error) {
            console.log(error);
            return reject(error);
          }
          if (result.id) {
            
            return reject(0);
          } else console.log("sku not duplicate", result, error, part_no);
          resolve(result);
        }
      );
    });
  },
  addVariant: (name) => {
    return new Promise((resolve, reject) => {
      pool.query(
        `insert into maz_ecommerce.variant set name= ?`,
        [name],
        (error, results, fields) => {
          if (error) {
            return reject(error);
          }
          resolve(results);
        }
      );
    });
  },

  addVariantValues: (id, values) => {
    return new Promise((resolve, reject) => {
      let sql = "INSERT INTO maz_ecommerce.variant_values (variant_id,value) values ";
      values.forEach((value) => {
        sql += '("' + id + '","' + value + '"),';
      });
      sql = sql.slice(0, -1);
      pool.query(sql, [], (error, results, fields) => {
        if (error) {
          return reject(error);
        }
        return resolve(results);
      });
    });
  },
  searchAndAddVariantValue: (variant_id, variant_values) => {
    console.log("in saerch")
    console.log("variant values are")
    const promises=[];
    return new Promise((resolve, reject) => {
      variant_values.forEach((value) => {
        promises.push(
        searchProductVariantValue(value).then((result)=>
        {
          console.log("search results",result)
          if(result.length)
          {
            return result
          }
          else
          {
            console.log("not found",result)
            return addVariantValue(variant_id,value)
          }
        })
        )
        
      })
      console.log("searcg and promises",promises)

      Promise.all(promises).then((result)=>
      {
       return resolve(result)
      })
      .catch((err)=>
      {
        return reject(err)
      })
    })
  },
  addProductVariants: (id, combinations) => {
    console.log("fafafafa");
    return new Promise((resolve, reject) => {
      let sql =
        "INSERT IGNORE INTO maz_ecommerce.product_variants (product_id,product_variant_name,sku,regular_price) values ";
      combinations.forEach((combination) => {
        sql +=
          '("' +
          id +
          '","' +
          combination.product_variant_name +
          '","' +
          combination.sku +
          '","' +
          combination.regular_price +
          '"),';
      });
      sql = sql.slice(0, -1);
      pool.query(sql, [], (error, results, fields) => {
        if (error) {
          console.log("error", error);
          return reject(error);
        }
        console.log("data", results);
        resolve(results);
      });
    });
  },

  searchProductVariant: (start, end, combinations) => {
    const prmises = [];
    const pm = [];
    console.log(start, " hh ", end);
    for (let i = start; i < start + end; i++) {
      vv = combinations[i - start].product_variant_name.split("_");
      console.log("kk", vv.length);

      for (var j = 0; j < vv.length; j++) {
        console.log("variant value split ",vv[j])

        pm.push(
          searchProductVariantValue(vv[j]).then((re) => {
            // console.log(results);
            console.log("i is ", i);
            // let preturn = addProductVariantDetails(i, results[0].id);
            // console.log(typeof(preturn));
            // console.log(preturn);
            console.log("re", re);
            return addProductVariantDetails(i, re[0].id);
            // addProductVariantDetails(i, results[0].id);
            // console.log('promises', prmises);
            // pm = prmises;
          })
        );
      }
    }

    console.log("pm", pm);
    console.log("promises array is", pm); //it prints null
    return Promise.all(pm);
  },
  countProducts: (callBack) => {
    pool.query(
      `SELECT COUNT(*) AS count FROM maz_ecommerce.product`,
      [],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        return callBack(null, results[0].count);
      }
    );
  },
  getProductsPerPage: (data, callBack) => {
    pool.query(
      `SELECT *from (select p.id,p.name,p.category_id, p.price,pi.path from maz_ecommerce.product as p left join maz_ecommerce.product_images as pi on p.id=pi.product_id GROUP BY p.id)as Sub limit ${data.skip},${data.limit}`,
      [],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        return callBack(null, results);
      }
    );
  },
  getAllProducts: (callBack) => {
    pool.query(
      `select p.id,p.name,p.category_id, p.regular_price,p.part_no,p.vehicle_id,pi.path from maz_ecommerce.product as p left join maz_ecommerce.product_images as pi on p.id=pi.product_id `,
      [],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        return callBack(null, results);
      }
    );
  },
  getAllVariantsAndItsValues: (callBack) => {
    pool.query(
      `SELECT v.id, v.name as variants, 
      (SELECT group_concat(CONCAT(vv.value)) FROM maz_ecommerce.variant_values as vv WHERE v.id = vv.variant_id GROUP BY (v.name)) AS variant_value
      FROM maz_ecommerce.variant as v`,
      [],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        return callBack(null, results);
      }
    );
  },
  getProductandVariantsById: (id, callBack) => {
    // group by v.name
    pool.query(
      `SELECT p.name as product_name,p.price,p.product_description,p.quantity,p.sku, group_concat(distinct pi.path) as image_paths, p.supplier_id, p.category_id,pv.id, pv.product_id,group_concat(distinct (concat("'id':'",pv.id,"','product_variant_name':'",pv.product_variant_name,"','sku':'",pv.sku,"','regular_price':",pv.regular_price)) SEPARATOR ' ') as combinations,v.name as variant_name,
      group_concat(distinct  vv.value) as variant_values,
       pv.regular_price,pv.stock_quantity,pv.sku,v.id as variant_id FROM maz_ecommerce.product as p
      inner join maz_ecommerce.product_variants as pv on p.id=pv.product_id
	    left outer join maz_ecommerce.product_images as pi on p.id=pi.product_id
      inner join maz_ecommerce.product_variant_details as pvd on pv.id=pvd.product_variant_id 
      inner join maz_ecommerce.variant_values as vv on pvd.variant_value_id=vv.id 
      inner join maz_ecommerce.variant as v on vv.variant_id=v.id where p.id=? group by v.name `,
      [id],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        return callBack(null, results);
      }
    );
  },
  getProductWithoutVariantsById: (id, callBack) => {
    pool.query(
      `SELECT  p.name as product_name,p.regular_price,p.part_no ,p.product_description,p.stock_quantity,p.supplier_id,p.category_id,p.application,p.package,p.oem_no,p.part_no,p.vehicle_id,p.cross_ref, group_concat(distinct pi.path) as image_paths from maz_ecommerce.product as p
      left outer join maz_ecommerce.product_images as pi on p.id=pi.product_id where p.id=?  `,
      [id],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        return callBack(null, results);
      }
    );
  },
  uploadProductImages: (id, files, callBack) => {
    return new Promise((resolve,reject)=>
    {
      let sql = "INSERT INTO maz_ecommerce.product_images (product_id, path) values ";
      files.forEach((file) => {
        file.path = file.path.replace("\\", "//");
        // file.path = path.join(__dirname,file.path)
  
        sql += '("' + id + '","' + file.path + '"),';
      });
      sql = sql.slice(0, -1);
      pool.query(sql, [], (error, results, fields) => {
        if (error) {
          return reject(error);
        }
        console.log("image uploaded",results)
        return resolve(results);
      });
    })
    
 
  },
  getProductsByCategoryId: (id, callBack) => {
    pool.query(
      `select p.id,p.name,p.category_id,p.part_no, p.regular_price,pi.path from maz_ecommerce.product as p left join maz_ecommerce.product_images as pi on p.id=pi.product_id  where p.category_id=?  `,
      [id],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        return callBack(null, results);
      }
    );
  },
  getProductsByVehicleId: (id, callBack) => {
    pool.query(
      `select p.id,p.name,p.category_id,p.part_no, p.regular_price,pi.path from maz_ecommerce.product as p left join maz_ecommerce.product_images as pi on p.id=pi.product_id  where p.vehicle_id=?  `,
      [id],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        return callBack(null, results);
      }
    );
  },
  isProductHasVariants: (id, callBack) => {
    pool.query(
      `select has_variant from maz_ecommerce.product where id = ?`,
      [id],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        return callBack(null, results[0]);
      }
    );
  },
  searchProduct: (query, callBack) => {
    pool.query(
      `select * from maz_ecommerce.product where name LIKE %${query}%`,
      [id],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        return callBack(null, results);
      }
    );
  },

  updateProductById: (id, data) => {
    return new Promise((resolve,reject)=>
    {
    pool.query(
      `update maz_ecommerce.order_details set `+Object.keys(data).map(key => `${key} = ?`).join(", ") +" where id =?",
      [
        ...Object.values(data),
        id
    ],
          (error, results, fields) => {
            if (error) {
              console.log("update rerror",error)
              return reject(error);
            }
            console.log("update results",results)
              resolve(results);
          }
        );
      })
  },
  deleteProductById: (id, callBack) => {
    pool.query(
      `delete from maz_ecommerce.product where id = ?`,
      [id],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        console.log("results are " + results[0]);
        return callBack(null, results);
      }
    );
  },
  deleteAllProducts: (callBack) => {
    pool.query(`delete from maz_ecommerce.product`, [], (error, results, fields) => {
      if (error) {
        console.log("error occured " + err);
        return callBack(error, null);
      }
      console.log("results are " + results[0]);
      return callBack(null, results);
    });
  },
  deleteVariantsByProductId: (id) => {
    return new Promise((resolve,reject)=>{
    pool.query(
      `DELETE vv.*,pvd.*,pv.* FROM maz_ecommerce.product_variants as pv
    inner join maz_ecommerce.product_variant_details as pvd on pv.id=pvd.product_variant_id 
    inner join maz_ecommerce.variant_values as vv on pvd.variant_value_id=vv.id  where pv.product_id=${id}
    `,

      [],
      (error, results, fields) => {
        if (error) {
          console.log("error occured in deleting " ,err);
          return reject(error);
        }
        console.log("deleting results are " ,results);
              resolve(results);
      }
    );
  });
  },

  getSearchProduct: (p_no,c_id,v_id, callBack) => {
    pool.query(
      `SELECT p.id, p.name as product_name,p.regular_price ,p.product_description,p.stock_quantity,p.supplier_id,p.category_id,p.application,p.package,p.oem_no,p.part_no,p.vehicle_id, group_concat(distinct pi.path) as image_paths from maz_ecommerced.product as p
      left outer join maz_ecommerce.product_images as pi on p.id=pi.product_id where p.part_no=? and p.category_id=? and p.vehicle_id=? group by p.id `,
      [p_no,c_id,v_id],
      (error, results, fields) => {
        if (error) {
          return callBack(error, null);
        }
        return callBack(null, results);
      }
    );
  },
};


