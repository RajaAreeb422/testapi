const pool = require("../../config/database");

module.exports = {
  addVehicle: (data, callBack) => {
    pool.query(
      `insert into maz_ecommerce.vehicle set name=? , type=?, model=?, year=?`,
        [
        data.name,
        data.type,
        data.model,
        data.year
      ],
      (error, results, fields) => {
        if (error) {
          return callBack(error,null);
        }
        return callBack(null,results);
      }
    );
  },
  getAllVehicles: (callBack) => {
    pool.query(
      `select * from maz_ecommerce.vehicle`,
      [],
      (error, results, fields) => {
        if (error) {
          return callBack(error,null);
        }
        return callBack(null, results);
      }
    );
  },
  getParentCategories: (callBack) => {
    pool.query(
      `select * from maz_ecommerce.category where maz_ecommerce.category.parent is null`,
      [],
      (error, results, fields) => {
        if (error) {
          return callBack(error,null);
        }
        return callBack(null, results);
      }
    );
  },
  getVehicleById: (id, callBack) => {
    pool.query(
      `select * from maz_ecommerce.vehicle where id = ?`,
      [id],
      (error, results, fields) => {
        if (error) {
          return callBack(error,null);
        }
        return callBack(null, results[0]);
      }
    );
  },
  getCategoryByProductId: (id, callBack) => {
    pool.query(
      `select * from maz_ecommerce.category inner join maz_ecommerce.product on maz_ecommerce.category.id = maz_ecommerce.product.category_id where maz_ecommerce.product.id = ?`,
      [id],
      (error, results, fields) => {
        if (error) {
          return callBack(error,null);
        }
        return callBack(null, results);
      }
    );
  },

  updateVehicleById: (id,data, callBack) => {
    pool.query(
      `update maz_ecommerce.vehicle set `+Object.keys(data).map(key => `${key} = ?`).join(", ") +" where id =?",
        [
          ...Object.values(data),
          id
      ],
      (error, result, fields) => {
        if (error) {
          return callBack(error,null);
        }
        return callBack(null, result);
      }
    );
  },
  deleteVehicleById: (id, callBack) => {
    pool.query(
      `delete from maz_ecommerce.vehicle where id = ?`,
      [id],
      (error, results, fields) => {
        if (error) {
          console.log("error occured "+err)
          return callBack(error,null);
        }
        console.log("results are "+results[0])
        return callBack(null,results);
      }
    );
  },
  deleteAllVehicles: (callBack) => {
    pool.query(
      `delete from maz_ecommerce.vehicle`,
      [],
      (error, results, fields) => {
        if (error) {
          console.log("error occured "+err)
          return callBack(error,null);
        }
        console.log("results are "+results[0])
        return callBack(null,results);
      }
    );
  },

};