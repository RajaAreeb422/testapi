const router = require("express").Router();
const { checkToken, isAdmin } = require("../../auth/token_validation");
const {
getAllVehicles,
addVehicle,
deleteAllVehicles,
getVehicleById,
updateVehicleById,
deleteVehicleById,
getCategoryByProductId,
getParentCategories

} = require("./vehicle.controller");
const use = fn => (req,res,next)=>
{
    Promise.resolve(fn(req,res,next)).catch(next)
}
router.get("/", use(getAllVehicles));
//router.get("/getParentCategories", use(getParentCategories));
router.get("/:id",use(getVehicleById));
//By giving product id will give you the category assign to that product 
//router.get("/getCategoryOfProduct",use(getCategoryByProductId));
router.post("/", use(addVehicle));
router.delete("/", use(deleteAllVehicles));
router.put("/:id",use(updateVehicleById));
router.delete("/:id",use(deleteVehicleById));
module.exports = router;